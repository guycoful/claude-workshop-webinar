---
name: linkedin-post-machine
description: Create high-quality LinkedIn posts in the user's voice and, only after explicit approval, publish them through the supplied LinkedIn posting script. Use this skill when the user asks to write, improve, format, prepare, or publish a LinkedIn post in Hebrew or English, or asks to create an optional accompanying image.
---

# LinkedIn Post Machine

Create a complete, personal LinkedIn post and prepare it for publication. Keep writing and publishing as separate stages.

## Safety rules

- Never publish, send, or call a publishing script without the user's explicit approval in the current conversation.
- Always show the full final post before publication.
- Ask for a clear approval, such as "yes" or an unambiguous publication command, and wait for it.
- Treat credentials, access tokens, client secrets, and API keys as private. Never print, commit, upload, or place them in shared folders.
- Do not invent personal experiences, metrics, customers, quotes, or results. Ask for missing facts or write a clearly labeled hypothetical draft.
- Do not claim that a post was published unless the publishing command returned a success result and post identifier.

## Workflow

### 1. Understand the request

If the user did not provide a topic, ask:

> What topic would you like to create a LinkedIn post about?

Collect only the context needed to write accurately:

- Topic and intended audience
- The user's real experience, observation, or opinion
- Desired language and tone
- Any tool, company, industry, or person that may be named
- Whether the user wants a text-only post or an image too

Do not ask unnecessary questions when the user already supplied enough context.

### 2. Draft the post

Use the user's own voice. Prefer a concrete story over generic advice.

Default structure:

1. Hook: one direct, interesting sentence.
2. Relatability bridge: connect to a common assumption or frustration.
3. Personal story: three to five sentences with specific, verified details.
4. Revelation: the unexpected result or insight.
5. Broader lesson: explain why the insight matters to the reader.
6. Call to action: end with a genuine question.

Default format:

- 180-280 words unless the user requests another length.
- Short paragraphs of one to three sentences.
- Conversational, honest, and grounded.
- Use "I" and "you" when appropriate.
- Use at most two emojis, and only when they fit the user's voice.
- End with a real question rather than a block of hashtags.
- Do not use bullet points unless the post is intentionally a playbook.
- Name real tools when that improves clarity instead of hiding behind vague terms.

Avoid hype and empty marketing language. Do not use these terms unless the user explicitly requests them: "synergy", "leverage", "innovative", "cutting-edge", "unlock", "game-changer", or "revolutionary".

When the user provides examples of previous posts, analyze their repeated structure, vocabulary, paragraph length, and calls to action. Match the pattern without copying sentences.

### 3. Review before approval

Show the complete post exactly as it should appear on LinkedIn. Then ask:

> Are you satisfied with the post?

Wait for explicit approval. If the user requests changes, revise and show the complete post again. Do not publish based on an ambiguous reaction such as "looks good" unless it clearly authorizes publication in context.

### 4. Publish only after approval

If the supplied project contains `linkedin_post.py` and a configured `credentials.json`, use:

```text
python linkedin_post.py "FULL POST TEXT HERE"
```

For an approved image:

```text
python linkedin_post.py "FULL POST TEXT HERE" "path/to/image.jpg"
```

Use the project-specific path when it is available. Do not create or modify credentials automatically. On first use, the script may open a browser for LinkedIn OAuth and save a token beside the credentials file.

After running the script:

- Report success only when the command succeeds and returns a post ID.
- For authentication failures, explain the exact next action without exposing secrets.
- For other HTTP failures, report the status and response summary without reproducing credentials or tokens.

If no publishing script is available, provide the approved post as copy-ready text and state that it has not been published.

## Optional image workflow

Offer an image only when it supports the post. Text-only remains the default.

Choose one route:

- Story: one concrete narrative scene from the post, with no template, frame, logo, or text-heavy infographic.
- Technical: a branded infographic, comparison, or framework using the user's supplied template and brand style.

For a story image, describe the subject, exact moment, emotion, setting, illustration style, and palette. Avoid generic concepts and text inside the image.

For a technical image, preserve the supplied template elements, identify three to five concepts that must appear, and specify layout, labels, connecting lines, contrast, and brand colors. Never invent a logo or brand system.

If `generate_fal.py` is available, save a prompt JSON and run:

```text
python generate_fal.py "prompts/post_<slug>.json" "images/posts/<slug>_final.jpg" "4:5"
```

The image must be shown together with the post and approved before publication. Do not publish an image that the user did not approve.

## Final quality check

Before asking for approval, verify:

- Every factual personal detail came from the user or a supplied source.
- The hook is specific and understandable without extra context.
- The post has one clear idea.
- Paragraphs are easy to scan on mobile.
- The tone sounds human rather than corporate.
- The final line is a genuine question.
- No forbidden hype, invented claims, secrets, or unintended hashtags appear.
