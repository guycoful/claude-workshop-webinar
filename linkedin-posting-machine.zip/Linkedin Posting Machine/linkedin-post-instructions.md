# linkedin-post (core — text only)

Creates a complete LinkedIn text post in your own voice and publishes it. No image, no extra accounts, no extra API keys — just your LinkedIn app credentials from setup step 1.

Want images too? That's a separate, optional upgrade — see `../אופציונלי - שדרוג תמונה/image-upgrade-instructions.md`. It's not required to start posting.

---

## STEP 1 — Ask for Topic

Ask the user exactly this:

> "What topic would you like to create a LinkedIn post about?"

Wait for the response before continuing.

---

## STEP 2 — Generate the Post Text

Write a LinkedIn post in **your own voice**. Before running this for real, replace this section with:

- 3–5 examples of your own past posts (the ones that actually performed well)
- The structure that repeats across them
- Words/phrases you never use

Until you've done that, use this generic structure as a starting point:

### Structure (in order)
1. **Hook** (1 sentence) — Bold, direct, sometimes provocative. Can be a statement or question. Optional single emoji at the end.
2. **Relatability bridge** (1–2 sentences) — "I know what you think." or a common assumption/frustration the reader has.
3. **Personal story** (3–5 sentences) — Open with "I recently…" or "I always struggled with…". A specific, concrete anecdote about the topic. Real detail, not generic.
4. **Revelation** (1–2 sentences) — "Here's where it got interesting…" or describe the surprising result/insight.
5. **Broader lesson** (2–3 sentences) — What does this mean for the reader? Draw the bigger implication.
6. **CTA** (1 sentence) — Direct engagement question + 1 emoji. Examples: "Curious? Let's exchange! 😁" / "Did you try this? Let's exchange."

### Tone & Format Rules
- Conversational and honest — sounds like a person sharing real experience, not a marketer
- Short paragraphs (1–3 sentences each), separated by a blank line
- Heavy use of "I" and "you" — personal, never corporate
- Enthusiastic but grounded — never hype-y, never "game-changing" or "revolutionary"
- 180–280 words total
- Maximum 2 emojis in the entire post
- No bullet lists, UNLESS the post is a "playbook" format — in that case numbered items are fine
- Never use: "synergy", "leverage", "innovative", "cutting-edge", "unlock", "game-changer"
- End on a real question, not a wall of hashtags — data consistently shows this correlates with reach
- Naming real tools/competitors by name beats generic "automation" talk
- Don't repeat the same post template several days in a row

### Core Themes (content pillars)
Replace with your own 3–5 pillars. Example set: Claude Code capabilities and real-world use cases · AI automation with practical business impact · personal transformation through AI tools · the honest limits of AI (what stays human) · agentic AI and what it actually delivers.

---

## STEP 3 — Ensure Credentials are Configured

Check that `credentials.json` (next to `linkedin_post.py`, copied from `credentials.json.example`) has your real `linkedin.client_id` and `linkedin.client_secret` filled in. Never commit this file — keep it out of git and out of any shared/synced folder.

---

## STEP 4 — Deliver Results

Show the full post text, formatted exactly as it would appear on LinkedIn (blank lines between paragraphs, ready to copy-paste).

---

## STEP 5 — Ask for Approval and Post to LinkedIn

**CRITICAL RULES:**
- NEVER post without explicit approval
- Always show the post text first (Step 4)
- Always ask: "Are you satisfied with the post?" and wait for a clear "yes" before publishing

Once approved, post using the Python script:

```bash
py "<your project folder>\linkedin_post.py" "FULL POST TEXT HERE"
```

**First-time / token expired:** The script opens a browser for LinkedIn OAuth and saves the token to `credentials.json`. All subsequent runs reuse the saved token silently.

**On success:** The script prints the post ID.

---

## Error Handling

| Error | Action |
|---|---|
| `credentials.json` not found | Copy `credentials.json.example`, rename it, fill in your real `client_id`/`client_secret`. |
| 401 / token expired | The script automatically clears the saved token and re-runs the browser OAuth flow. |
| No auth code received | Retry — make sure you approve the LinkedIn authorization screen in the browser tab that opens. |

---

## Want images too?

That's an optional, separate upgrade — a branded template image or a from-scratch illustration generated per post. It needs its own account and API key (fal.ai) and, for the branded-template route, your own template pushed to a public GitHub repo. None of that is required to post text. See `../אופציונלי - שדרוג תמונה/image-upgrade-instructions.md` when you're ready for it.
