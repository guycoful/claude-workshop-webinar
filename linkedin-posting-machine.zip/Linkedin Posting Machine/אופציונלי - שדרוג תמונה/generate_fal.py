import os
import sys
import json
import time
import requests

def run():
    if len(sys.argv) < 3:
        print("Usage: python generate_fal.py <prompt_json_file> <output_file> [aspect_ratio]")
        sys.exit(1)

    prompt_file = sys.argv[1]
    output_file = sys.argv[2]
    aspect_ratio_arg = sys.argv[3] if len(sys.argv) > 3 else None

    # Keep credentials.json next to this script, and never commit it or put it in a
    # synced/shared folder. Fill it in using credentials.json.example as the template.
    secrets_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "credentials.json")
    if not os.path.exists(secrets_path):
        print(f"ERROR: secrets file not found at {secrets_path}")
        sys.exit(1)

    with open(secrets_path, 'r') as f:
        secrets = json.load(f)
    api_key = secrets.get("fal.ai", {}).get("api_key")

    if not api_key:
        print(f"ERROR: fal.ai api_key not found in {secrets_path}")
        sys.exit(1)

    with open(prompt_file, 'r', encoding='utf-8') as f:
        prompt_json = json.load(f)

    model = prompt_json.get("model", "fal-ai/nano-banana-pro")
    prompt_text = prompt_json.get("prompt", "")
    negative_prompt = prompt_json.get("negative_prompt", "")
    if negative_prompt:
        prompt_text = f"{prompt_text}\n\nAvoid: {negative_prompt}"

    api_parameters = prompt_json.get("api_parameters", {})
    ar = aspect_ratio_arg or api_parameters.get("aspect_ratio", "4:5")
    resolution = api_parameters.get("resolution", "1K")
    output_format = api_parameters.get("output_format", "jpeg")
    image_urls = prompt_json.get("image_input")

    submit_url = f"https://queue.fal.run/{model}"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Key {api_key}"
    }

    payload = {
        "prompt": prompt_text,
        "aspect_ratio": ar,
        "resolution": resolution,
        "output_format": output_format
    }

    if image_urls:
        payload["image_urls"] = image_urls

    print(f"Creating task via fal.ai API ({model})...")
    try:
        response = requests.post(submit_url, headers=headers, json=payload, timeout=30)
        response.raise_for_status()
        result = response.json()
    except Exception as e:
        print(f"ERROR creating task: {e}")
        if 'response' in locals() and response is not None:
            print(response.text)
        sys.exit(1)

    request_id = result.get("request_id")
    status_url = result.get("status_url")
    response_url = result.get("response_url")
    if not request_id or not status_url or not response_url:
        print("ERROR: Missing request_id/status_url/response_url in submit response")
        print(result)
        sys.exit(1)

    print(f"Task created successfully. Request ID: {request_id}. Polling...")

    attempts = 0
    while attempts < 60:
        time.sleep(4)
        attempts += 1

        try:
            poll_resp = requests.get(status_url, headers=headers, params={"logs": "0"}, timeout=15)
            poll_resp.raise_for_status()
            poll_result = poll_resp.json()
        except Exception as e:
            print(f"Poll {attempts} Error: {e}")
            continue

        status = poll_result.get("status")
        print(f"Poll {attempts}: status = {status}")

        if status == "COMPLETED":
            try:
                result_resp = requests.get(response_url, headers=headers, timeout=30)
                result_resp.raise_for_status()
                result_data = result_resp.json()
            except Exception as e:
                print(f"ERROR fetching result: {e}")
                sys.exit(1)

            images = result_data.get("images", [])
            if images:
                image_url = images[0]["url"]
                print(f"Downloading image from {image_url}")
                try:
                    img_resp = requests.get(image_url, timeout=30)
                    img_resp.raise_for_status()
                    with open(output_file, 'wb') as f:
                        f.write(img_resp.content)
                    print(f"Successfully saved to {output_file}")
                    sys.exit(0)
                except Exception as e:
                    print(f"ERROR downloading image: {e}")
                    sys.exit(1)
            else:
                print("ERROR: Could not find image URL in result. Dumping data:")
                print(json.dumps(result_data, indent=2))
                sys.exit(1)

        elif status in ("FAILED", "ERROR"):
            print("ERROR: Task failed on server side.")
            print(json.dumps(poll_result, indent=2))
            sys.exit(1)

    print("ERROR: Timed out waiting for job completion")
    sys.exit(1)

if __name__ == "__main__":
    run()
