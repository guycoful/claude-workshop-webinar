# linkedin-post — optional image upgrade

This extends the core text-only flow (`../linkedin-post-instructions.md`) with a generated image per post. It is **not required** to post — only add this once the core flow already works for you.

Two visual routes are supported — pick one per post.

| Route | What it produces | Needs a public GitHub repo? |
|---|---|---|
| **1 — Technical** | A branded infographic card rendered inside your template frame (circuit-line edges, logo mark) — comparisons, frameworks, split layouts. | Yes |
| **2 — Story** | A standalone narrative illustration with no template, frame, or logo — one scene that shows the moment of the post's story. | No |

If you don't want to design a template or manage a GitHub repo, use **Route 2 only** — it skips the whole template/repo setup below and just needs the fal.ai key.

---

## Extra setup (once)

1. Create an API key at fal.ai (sign up, add a payment method, generate a key in the dashboard).
2. Add it to your existing `credentials.json` (the same file the core kit uses) — merge in the block from `credentials.optional-image.json.example` in this folder.
3. **Route 1 only:** design a branded template image (PNG) and push it to a public GitHub repo — see "Route 1 — Technical" below for the exact steps. Route 2 doesn't need this at all.

---

## Project Directories

| Resource | Path |
|---|---|
| Scripts | `generate_fal.py` (this folder) |
| Template PNG | `<your project folder>\Template_Post_2.png` (2048×2048 px) — Route 1 only |
| Prompts | `<your project folder>\prompts\` |
| Image output | `<your project folder>\images\posts\` |
| Brand style ref | `context_brand_style.example.json` (this folder) — copy and fill in your own colors/logo description |
| Public template URL | `https://raw.githubusercontent.com/<your-github-username>/<your-repo-name>/main/Template_Post_2.png` — Route 1 only |

See `example/` in this folder for a real prompt + the image it produced.

---

## STEP A — Choose a Visual Format

### Route 1 — Technical

Read your `context_brand_style.example.json` (copied and filled in) `_visual_formats._technical` block and pick the best fit:

| Format | When to use |
|---|---|
| **A — Bold Text + Person** | Personal/inspirational posts. Large title text + simple line-art confident figure. |
| **B — Tech Infographic** | Framework, system, or multi-part concept posts. Connected circular/hexagonal nodes + blue connecting lines. |
| **C — Split Layout** | Contrast/comparison posts. Two-column (e.g., AUTOMATE vs KEEP HUMAN) with central divider. |

Identify the 3–5 key concepts/elements that need to appear as labeled nodes or text in the visual.

### Route 2 — Story

Read the `_visual_formats._story` block and pick the best fit:

| Format | When to use |
|---|---|
| **STORY (default)** | Any post. One full-bleed narrative scene depicting the specific moment from the story in the post text — no card, no frame, no logo. |
| **A — Bold Text + Person** | Personal/inspirational posts where a short headline should dominate the scene. |
| **B — Concept Diagram** | Framework, system, or multi-part concept posts. Loose illustrated diagram, not a rigid infographic. |
| **C — Before/After Split** | Contrast/comparison posts. One scene split into two halves showing the same subject before/after. |

Identify the single concrete moment (or the two contrasted moments, for format C) that the illustration should depict — pull it directly from the "Personal story" beat of the post text, not an abstract concept.

---

## STEP B — Build the Nano Banana Pro Prompt

### Route 1 — Technical: Ensure Template is on GitHub

fal.ai's edit endpoint requires a **publicly accessible URL** for the reference image.

**Check if the template is already pushed:**
```bash
curl -s -o /dev/null -w "%{http_code}" \
  "https://raw.githubusercontent.com/<your-github-username>/<your-repo-name>/main/Template_Post_2.png"
```

If the response is **200**, the template is already there — skip to the URL assignment below.

**If not 200:** push the template to GitHub:
```bash
cd /tmp && git clone https://github.com/<your-github-username>/<your-repo-name>.git 2>/dev/null || true
cp "<your project folder>\Template_Post_2.png" \
  /tmp/<your-repo-name>/
cd /tmp/<your-repo-name>
git add "Template_Post_2.png"
git commit -m "Add LinkedIn post template"
git push origin main
```

**Set the permanent raw URL:**
```
TEMPLATE_URL = https://raw.githubusercontent.com/<your-github-username>/<your-repo-name>/main/Template_Post_2.png
```

This URL never expires — no re-upload needed on subsequent runs.

#### JSON structure to use (routes to the fal.ai edit endpoint):
```json
{
  "model": "fal-ai/nano-banana-pro/edit",
  "prompt": "Keep [describe your fixed template elements] exactly as shown in the reference image — do not alter or remove them. Fill the empty inner content area of the card with: <dense narrative of the visual concept — layout, title text, node labels, connecting lines, brand colors>. The scene background must stay consistent with the card. Primary accent: <your color>. Secondary accent: <your color>. Text color: <your color> for contrast on your background.",
  "negative_prompt": "dark background, black background, teal gradient, neon glow, off-brand colors, white text on light background, blurry text, low contrast, added logos, added wordmarks, removing the existing template elements, altering the background color",
  "image_input": [
    "https://raw.githubusercontent.com/<your-github-username>/<your-repo-name>/main/Template_Post_2.png"
  ],
  "api_parameters": {
    "aspect_ratio": "4:5",
    "resolution": "1K",
    "output_format": "jpeg"
  }
}
```

**Note:** The `"model": "fal-ai/nano-banana-pro/edit"` key is required for Route 1 — this routes the request to the image-editing endpoint. `image_input` is passed through to fal.ai's `image_urls` field by `generate_fal.py`.

### Route 2 — Story

Write a **story illustration prompt** — a dense narrative description of one scene, as if directing an illustrator. No template, no `image_input`, no card frame, no logo, no UI chrome.

#### What the prompt must describe
- **Subject & moment**: one clear character/subject in one specific moment tied to the post's story (e.g. "a man in his 30s hunched over a laptop at 11pm, desk cluttered with sticky notes and empty coffee cups, shoulders tense" — not "person working hard").
- **Emotion**: the feeling the scene should carry (overwhelmed, relieved, focused, surprised).
- **Style**: modern flat/semi-realistic editorial illustration, warm and human, the kind used in a thoughtful tech newsletter — not corporate clip-art, not a literal photo.
- **Palette**: lean on your brand colors as accent color (lighting, clothing, screen glow) against a light, airy background.
- **Text on image**: avoid it by default.

#### JSON structure to use:
```json
{
  "prompt": "<dense narrative description of the one scene — subject, moment, emotion, setting, style, palette lean>",
  "negative_prompt": "stock photo look, corporate clip-art, text-heavy infographic, dashboard UI, template card border, added logo or wordmark, blurry, low detail, watermark",
  "api_parameters": {
    "aspect_ratio": "4:5",
    "resolution": "1K",
    "output_format": "jpeg"
  }
}
```

**Note:** No `"model"` key needed — `generate_fal.py` defaults to `fal-ai/nano-banana-pro` (text-to-image) when there's no `"model"` key. No `image_input` — pure text-to-image generation.

---

## STEP C — Generate and Publish with Image

1. Save the prompt JSON to `prompts/post_<slug>.json`.
2. Generate:
   ```bash
   py generate_fal.py "prompts/post_<slug>.json" "images/posts/<slug>_final.jpg" "4:5"
   ```
3. Show the text and the image together, ask for approval, then publish with the image path as a second argument:
   ```bash
   py "<your project folder>\linkedin_post.py" "FULL POST TEXT HERE" "images/posts/<slug>_final.jpg"
   ```

---

## Error Handling

| Error | Action |
|---|---|
| Template URL returns non-200 (Route 1) | Push the template to GitHub using the commands above. |
| GitHub push fails (auth) | Run `gh auth login` and retry the push. |
| `generate_fal.py` fails with auth error | Check `fal.ai.api_key` in `credentials.json`. |
| Status goes to `FAILED` or submit returns non-2xx | Likely temporary fal.ai overload or an invalid parameter. Check the printed response body, wait 30 seconds, and retry. |
| `generate_fal.py` times out (60 polls) | Report the request ID and check the fal.ai dashboard. |
| Route 1 output looks off (border missing, colors wrong) | Offer to regenerate, reinforcing preservation language in the prompt. |
| Route 2 output looks off (wrong subject, generic look) | Offer to regenerate with a more concrete, specific scene description. |
